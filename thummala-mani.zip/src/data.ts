import { Skill, Project, EducationTimelineItem, AchievementItem, StatItem, PersonalData } from './types';
import profilePhoto from '../assets/images/profile.jpeg';

export const personalData: PersonalData = {
  name: "Thummala Mani",
  title: "Modern Web Platforms",
  subtitle: "High-performance websites and applications designed for ambitious startups.",
  imagePlaceholder: profilePhoto, // real profile headshot (assets/images/profile.jpeg)
  bio: "I design and develop modern websites and mobile applications that combine stunning design with powerful functionality. My goal is to build fast, secure, scalable, and user-focused digital experiences that help individuals, startups, and businesses grow online.",
  subBio: "I specialize in designing and developing modern websites and mobile applications that combine exceptional performance with elegant design. From responsive frontends and secure backends to optimized databases and scalable architectures, I build digital products that are fast, reliable, user-friendly, and engineered for long-term success.",
  email: "thummalamani567@gmail.com",
  phone: "+91 98765 43210", // representative Indian mobile number
  linkedin: "https://www.linkedin.com/in/thummala-mani", // placeholder link
  github: "https://github.com/thummalamani", // placeholder or real link
  resumeUrl: "#", // clickable anchor triggers download or view
};

// Helper to get active profile data
export const getActiveProfile = (): PersonalData => {
  if (typeof window === 'undefined') return personalData;
  try {
    const stored = localStorage.getItem('profile_data');
    if (stored) {
      const parsed = JSON.parse(stored);
      return { 
        ...personalData, 
        ...parsed,
        imagePlaceholder: parsed.imagePlaceholder || personalData.imagePlaceholder
      };
    }
  } catch (e) {
    console.error('Error loading custom profile data', e);
  }
  return personalData;
};

// Helper to save profile data updates
export const saveProfileData = (data: Partial<PersonalData>) => {
  if (typeof window === 'undefined') return;
  try {
    const active = getActiveProfile();
    const updated = { ...active, ...data };
    localStorage.setItem('profile_data', JSON.stringify(updated));
    window.dispatchEvent(new Event('storage'));
    window.dispatchEvent(new CustomEvent('profileUpdate', { detail: updated }));
  } catch (e) {
    console.error('Error saving profile data', e);
  }
};


export const skillsData: Skill[] = [
  { name: "Python", category: "Technical", level: 92, iconName: "Terminal" },
  { name: "Data Structures", category: "Technical", level: 88, iconName: "Cpu" },
  { name: "Problem Solving", category: "Technical", level: 90, iconName: "Brain" },
  { name: "JavaScript", category: "Technical", level: 85, iconName: "Code" },
  { name: "HTML / CSS", category: "Technical", level: 90, iconName: "FileCode" },
  { name: "React & Node.js", category: "Practical", level: 82, iconName: "Database" },
  { name: "Git & Version Control", category: "Practical", level: 85, iconName: "GitBranch" },
  { name: "Linux & Shell Scripting", category: "Practical", level: 80, iconName: "Settings" },
  { name: "Communication Skills", category: "Soft Skills", level: 93, iconName: "MessageSquare" },
  { name: "Team Collaboration", category: "Soft Skills", level: 88, iconName: "Users" },
  { name: "Time Management", category: "Soft Skills", level: 85, iconName: "Clock" },
];

export const statsData: StatItem[] = [
  { label: "DSA Problems Solved", value: "----", suffix: "", description: "Across LeetCode, HackerRank", iconName: "Flame" },
  { label: "Academic CGPA", value: "----", suffix: "", description: "Computer Science Major", iconName: "GraduationCap" },
  { label: "Completed Projects", value: "----", suffix: "", description: "Active repositories & web portals", iconName: "Briefcase" },
  { label: "Coding Hours Accumulated", value: "----", suffix: "", description: "Hands-on engineering commits", iconName: "Clock" },
];

export const projectsData: Project[] = [
  {
    id: "proj-1",
    title: "DSA VisuEngine: Graph and Tree Visualizer",
    description: "An interactive, web-based state machine that visualizes sorting, graph traversal algorithms (Dijkstra, BFS, DFS), and binary tree balances in real-time.",
    longDescription: "Built specifically to help students visualize structural state transitions. Users can interactively draw nodes, place weighted routes, adjust traversal speeds, and step backward or forward through standard queue/stack updates.",
    tags: ["TypeScript", "React", "motion", "Tailwind CSS"],
    imageUrl: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "https://github.com/thummalamani/dsa-visualizer",
    category: "Algorithms",
    featured: true
  },
  {
    id: "proj-2",
    title: "EcoSphere: Intelligent Supply Chain CRM",
    description: "A gorgeous full-stack responsive web dashboard built with analytics widgets tracking inventory optimization, sustainability indexing, and delivery chains.",
    longDescription: "A smart workspace focusing on carbon footprint simulation in local delivery fleets. Integrates rich interactive charts showing shipment trends, driver routing recommendations, and modern CSV report generators.",
    tags: ["React", "Express", "Recharts", "Tailwind CSS"],
    imageUrl: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "https://github.com/thummalamani/ecosphere-crm",
    category: "Web Dev",
    featured: true
  },
  {
    id: "proj-3",
    title: "PyScope: Python Lexical Code Analyzer",
    description: "A Python automation tool that lexes and parses code structures to render structural indentation mapping, complexity statistics, and unused imports.",
    longDescription: "Implemented using local parsing and regular expression tokenization, this Python script reads script source code and produces a formatted markdown report detailing time-complexity warning indicators and style scores.",
    tags: ["Python", "AST", "CLI", "Regex Rules"],
    imageUrl: "https://images.unsplash.com/photo-1526374965328-7f61d4dc18c5?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "https://github.com/thummalamani/pyscope-analyzer",
    category: "AI & ML",
    featured: true
  },
  {
    id: "proj-4",
    title: "NextCheck: Developer Task Orchestrator",
    description: "Multi-client task manager utilizing structural local storage workspaces, category filtering, priority metrics, and beautiful fade animations.",
    longDescription: "A minimalist workspace application supporting markdown notes, active focus pomodoro countdown tags, and progress logs aimed at helping CSE students manage assignment targets.",
    tags: ["React", "Tailwind CSS", "LocalStorage", "lucide-icons"],
    imageUrl: "https://images.unsplash.com/photo-1484417894907-623942c8ea29?auto=format&fit=crop&q=80&w=800",
    liveUrl: "#",
    githubUrl: "https://github.com/thummalamani/nextcheck",
    category: "Web Dev",
    featured: false
  }
];

export const educationHistory: EducationTimelineItem[] = [
  {
    id: "edu-1",
    institution: "St. John's College of Engineering & Technology",
    degree: "B.Tech of Computer Science & Engineering",
    fieldOfStudy: "Algorithms, Database Systems, Computer Networks & AI",
    duration: "2023 - Present",
    grade: "9.12 CGPA (Pre-Final Year)",
    description: "Undertaking specialized course study focus. High academic performer with active contributions to coding panels, programming workshops, and peer teaching initiatives.",
    bulletPoints: [
      "Secured rank in top ---- of CSE department",
      "Executive Lead of student-led Technical Club organizing mini-hackathons",
      "Core courses: Algorithms, Database Management, Operating Systems, Computer Architecture"
    ],
    iconType: "university"
  },
  {
    id: "edu-2",
    institution: "Sri Chaitanya Junior Academy College",
    degree: "Intermediate Board Certification (MPC Block)",
    fieldOfStudy: "Mathematics, Physics, Chemistry stream",
    duration: "2021 - 2023",
    grade: "---- Percentile",
    description: "Completed rigorous preparatory program specializing in analytical mathematics and general physics problems.",
    bulletPoints: [
      "Excellent mastery in Calculus, Linear Algebra, and mechanics principles",
      "Perfect grade score in Mathematics segment board exams"
    ],
    iconType: "college"
  },
  {
    id: "edu-3",
    institution: "High School of Academic Excellence",
    degree: "Secondary School Certificate (SSC)",
    fieldOfStudy: "General Academic Curriculum",
    duration: "2021",
    grade: "10 / 10 GPA",
    description: "Initial foundation year building scientific curiosity and foundational logical faculties.",
    bulletPoints: [
      "Secured perfect CGPA score in state board evaluation",
      "Championed local state mathematics olympiad"
    ],
    iconType: "school"
  }
];

export const achievementsList: AchievementItem[] = [
  {
    id: "ach-1",
    title: "HackerRank Problem Solving Champion",
    issuer: "HackerRank Certification Board",
    date: "Dec 2024",
    description: "Earned 5-Star Gold Badges in both Problem Solving and Python core challenges, answering complex tree traversal and dynamic programming queries.",
    category: "Certification"
  },
  {
    id: "ach-2",
    title: "Smart India Hackathon (SIH) Finalist",
    issuer: "Ministry of Education CSE Org",
    date: "Sep 2024",
    description: "Part of the 5-member team that designed a offline-resilient agricultural supply logistic monitor using geo-located SMS queues for rural farmers.",
    category: "Hackathon"
  },
  {
    id: "ach-3",
    title: "NPTEL National Certification - DS & Algorithms (Elite+Silver)",
    issuer: "IIT Kharagpur Academic Board",
    date: "Apr 2024",
    description: "Earned a national rank scoring ---- in a highly competitive 12-week course assessing advanced graph mechanics, recursion trees, and sorting limits.",
    category: "Certification"
  },
  {
    id: "ach-4",
    title: "LeetCode Milestone Badge: 400+ Solved",
    issuer: "LeetCode Online Evaluator",
    date: "Ongoing",
    description: "Regularly practice dynamic programming, arrays, two-pointer math and graph problems. Rank among top ---- global practitioners on competitive submissions.",
    category: "Milestone"
  }
];
